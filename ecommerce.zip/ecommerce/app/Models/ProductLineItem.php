<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ProductLineItem extends Model
{
    use HasFactory,SoftDeletes;

    protected $table='product_line_items';
    protected $fillable=['user_id','product_id','price','quantity','image','delivery_charge','session_id','ip_address','name'];

    public function products(){
        return $this->belongsTo(Product::class,'product_id','id');
    }
   
}
