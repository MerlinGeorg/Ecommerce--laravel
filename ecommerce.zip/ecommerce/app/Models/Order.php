<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Order extends Model
{
    use HasFactory,SoftDeletes;

    protected $table='orders';
    protected $fillable=['product_line_items_id','user_id','order_total_amount','total_delivery_charge','order_status','items_count'];

    protected $casts=[
        'product_line_items_id'=>'array'
    ];

    public function product_line_items(){
        return $this->hasMany(ProductLineItem::class,'id','product_line_items_id');
    }
}
