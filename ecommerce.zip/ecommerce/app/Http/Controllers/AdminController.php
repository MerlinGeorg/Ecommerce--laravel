<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cookie;


class AdminController extends Controller
{
    public function index()
    {

        return view('adminDashboard/dashboardWelcome');
    }

    public function getCookie()
    {
        $value = Cookie::get('access_token');
        return $value;
    }

    public function cookieLogin()
    {
        Cookie::queue('access_token', 'abcd', 600);
        return redirect('/getCookie');
    }

    public function getSession()
    {
        $value = session('access_token');
        return $value;
    }

    public function sessionLogin()
    {
        session(['access_token' => 'abcde']);
        return redirect('/getSession');
    }
}
