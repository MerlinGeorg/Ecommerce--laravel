<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

use App\Models\ProductLineItem;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;


class AuthController extends Controller
{
    public function index(Request $request)
    {
        $productList = $this->productList();

        return view('index', ['productList' => $productList,'session_id'=>$request->session_id]);
    }
    public function list()
    {
        $users = User::get(['id', 'name', 'email'])->toArray();
        return view('adminDashboard/customerList', ['customerList' => $users]);
    }
    public function account()
    {

        return view('account');
    }

    public function login(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'email'    => 'required|email',
                'password' => 'required|string|min:6'
            ]
        );

        if ($validator->fails()) {

            return view('account', ['errors' => $validator->errors()->all()]);
        }
        if (!$token = $this->guard()->attempt($validator->validated())) {

            return view('account', ['errors' => ['Login Failed.Please Try Again']]);
        }
        
        $productList = $this->productList();

        return view('index', ['productList' => $productList, 'user_id' => Auth::id(), 'access_token' => $token]);
    }

    public function logout(Request $request)
    {
        $request->session()->forget('user_id');
        $this->guard()->logout();

        return redirect('/login');
    }

    protected function guard()
    {
        return Auth::guard();
    }

    public function signup(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'name' => 'required|string|between:2,100',
                'email'    => 'required|email|unique:users',
                'password' => 'required|confirmed|min:6'
            ]
        );


        if ($validator->fails()) {
            
            return view('account', ['errors' => $validator->errors()->all()]);
        }

        $user = User::create(array_merge($validator->validated(), [
            'password' => bcrypt($request->password)
        ]));
       
        return view('account', ['success' => 'Successfully Registered.Please Login']);
        
    } //end register()

    public function getUserProfile(Request $request)
    {

        $validator = Validator::make(
            $request->all(),
            [
                'access_token' => 'required|string|between:2,100',
                'user_id' => 'required|integer'
            ]
        );
      if(!isset($request->user_id)){
          return redirect('/account');
      }
        
        $user = User::find($request->user_id)->toArray();
        
        $orders = Order::where('user_id', $request->user_id)->get(['id', 'user_id', 'order_total_amount', 'total_delivery_charge', 'order_status', 'items_count', 'created_at'])->toArray();
        return view('userProfile', ['access_token' => $request->access_token, 'user_id' => $request->user_id, 'user' => $user, 'orders' => $orders]);
    }

    protected function productList()
    {
        $productList = Product::get(['id', 'product_name', 'total_price', 'image'])->toArray();
        return $productList;
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'delivery_address' => 'required|string',
                'phone'=> 'required|digits:10',
                'order_id'=>'required|integer'
            ]
        );
  
        $user = User::find($id);
        $userData=tap($user)->update($request->all());
      //   $orderDetails=$this->getOrderById($request->order_id);
     //   $payment=Payment::where('order_id',$request->order_id)->first();
 
        return $this->paymentPage($request->order_id);
  
    }
   
    
    protected function getOrderById($id)
    {
        $order=Order::find($id)->toArray();
       foreach($order['product_line_items_id'] as $cart){
          $items[]= ProductLineItem::find($cart)->toArray();
       }
       $order['items']=$items;
     return $order;
    }

    public function paymentPage($id){
        $orderDetails=$this->getOrderById($id);
        $payment=Payment::where('order_id',$id)->first();
        $userData = User::find($payment['user_id'])->toArray();
        return view('payment',['order'=>$orderDetails,'razorpayOrderId'=>$payment['razorpay_order_id'],'userData'=>$userData]);
  
    }
     
} 
