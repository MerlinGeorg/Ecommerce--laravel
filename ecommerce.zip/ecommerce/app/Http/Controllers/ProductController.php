<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\ProductCategory;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function getSingleProduct(int $id)
    {
        $product = Product::with('productCategory:id,category_name')->where('id', $id)->get()->toArray()[0];

        return view('singleProduct', ['product' => $product]);
    }

    public function list()
    {
        $productList = Product::with('productCategory:id,category_name')->get(['id', 'product_name', 'category_id', 'total_delivery_time', 'product_cost', 'tax', 'delivery_charge', 'total_price', 'description', 'image'])->toArray();
        return view('adminDashboard/productList', ['productList' => $productList]);
    }

    public function productCreateForm()
    {
        $categories = $this->productCategory();
        return view('adminDashboard/createProduct', ['categories' => $categories]);
    }

    protected function productCategory()
    {
        $categories = ProductCategory::get(['id', 'category_name'])->toArray();
        return $categories;
    }
    public function insert(Request $request)
    {
        $categories = $this->productCategory();

        $validator = Validator::make(
            $request->all(),
            [
                'product_name'    => 'required|string',
                'category' => 'required|integer',
                'total_delivery_time' => 'required|integer',
                'product_cost' => 'required|numeric',
                'tax' => 'nullable|numeric',
                'delivery_charge'    => 'nullable|numeric',
                'description' => 'required|string',
                'image' => 'required|image'
            ]
        );

        if ($validator->fails()) {

            return view('adminDashboard/createProduct', ['errors' => $validator->errors()->all(), 'categories' => $categories]);
        }
        if (!isset($request->tax)) {
            $tax = 0;
        } else {
            $tax = $request->tax;
        }
        $image = $request->file('image');
        $fileName = $image->getClientOriginalName();
        $path = $image->storeAs('images/products', $fileName, ['disk' => 'public']);
        $product = Product::create(array_merge($validator->validated(), ['total_price' => $request->product_cost + $tax, 'image' => $path, 'category_id' => $request->category]));
        if ($product) {
            return view('adminDashboard/createProduct', ['success' => 'Product added.Add Another Product', 'categories' => $categories]);
        }
    }

    public function productSearch(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'product_name'    => 'required|string',
                'session_id' => 'required|integer'
            ]
        );
        if ($validator->fails()) {
        }
        $searchProduct = Product::where('product_name', 'LIKE', "%{$request->product_name}%")->get(['id', 'product_name', 'total_price', 'image'])->toArray();

        return view('index', ['searchProduct' => $searchProduct, 'session_id' => $request->session_id]);
    }
}
