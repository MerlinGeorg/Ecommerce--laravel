<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Razorpay\Api\Api;
use App\Models\Payment;
use Illuminate\Http\Request;
use App\Models\ProductLineItem;
use App\Models\User;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    const PAISA = 100;
    public function list()
    {
        $orderList = Order::get(['id', 'user_id', 'order_total_amount', 'total_delivery_charge', 'order_status', 'items_count', 'created_at'])->toArray();
        return view('adminDashboard/orderList', ['orderList' => $orderList]);
    }

    public function insert(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'product_line_items_id' => 'required|array',
                'user_id' => 'required|integer',
                'session_id' => 'required|integer'
            ]
        );

        if ($request->user_id == 0) {
            $cart = ProductLineItem::with('products:id,product_name,total_price')->where('session_id', $request->session_id)->get()->toArray();

            return view('addToCart', ['errors' => 'Please Login To Proceed', 'cart' => $cart]);
        }
        $total_delivery_charge = 0;
        $order_total_amount = 0;
        $items_count = 0;

        foreach ($request->product_line_items_id as $id) {
            $cart = ProductLineItem::find($id);

            $total_delivery_charge += $cart['delivery_charge'];
            $order_total_amount += $cart['price'];
            $items_count += $cart['quantity'];
        }
//$delivery_date=Date('Y-m-d',strtotime($orderDate.'+ days'));
//$delivery_date=$date->addDays($product['total_delivery_time']);
        $order = Order::create(array_merge($request->all(), [
            'order_total_amount' => $order_total_amount + $total_delivery_charge,
            'order_status' => 'order placed',
            'items_count' => $items_count,
            'total_delivery_charge' => $total_delivery_charge,
           // 'delivery_date'=>$delivery_date
        ]));

        $razorpayOrder = $this->createRazorpayOrder($order);

        return $this->getDeliveryAddress($request->user_id, $order['id']);
    }

    public function createRazorpayOrder($order)
    {
        $api = new Api(env('RAZORPAY_KEY_ID'), env('RAZORPAY_KEY_SECRET'));

        $data = [];
        $data['amount'] = $order['order_total_amount'] * self::PAISA;
        $data['currency'] = 'INR';

        $response  = $api->order->create($data);

        if (!empty($response)) {
            $payment = Payment::create([
                'order_id' => $order['id'],
                'razorpay_order_id' => $response->id,
                'user_id' => $order['user_id'],

            ]);
        }

        return $response->id;
    }

    public function getDeliveryAddress($user_id, $order_id)
    {
        $user = User::find($user_id)->toArray();
        return view('deliveryAddress', ['user' => $user, 'order_id' => $order_id]);
    }
}
