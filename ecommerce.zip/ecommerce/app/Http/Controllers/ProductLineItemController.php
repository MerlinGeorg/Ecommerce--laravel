<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use App\Models\ProductLineItem;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class ProductLineItemController extends Controller
{

    public function addToCartForm(Request $request)
    {

        $session_id = $request->session_id;
        if ($request->session_id == 0) {
            $ip_address = $request->ip();
            if (ProductLineItem::where('ip_address', $ip_address)->exists()) {
                $productLineItem = ProductLineItem::where('ip_address', $ip_address)->first();
                $session_id = $productLineItem['session_id'];
            }
        }
        $cart = $this->list($session_id);

        return view('addToCart', ['cart' => $cart, 'user_id' => $request->user_id, 'session_id' => $session_id]);
    }
    protected function list($session_id)
    {
        $cart = ProductLineItem::with('products:id,product_name,total_price')->where('session_id', $session_id)->get()->toArray();

        return $cart;
    }

    public function viewCart(Request $request)
    {

        $ip_address = $request->ip();
        $session_id =$request->session_id;
        $user_id =$request->user_id;
        if (ProductLineItem::where('ip_address', $ip_address)->exists()) {
            $productLineItem = ProductLineItem::where('ip_address', $ip_address)->first();
            $session_id = $productLineItem['session_id'];
            $user_id = $productLineItem['user_id'];
        }


        $cart = $this->list($session_id);

        alert()->success('Success')->autoclose(3500);
        return view('addToCart', ['cart' => $cart, 'user_id' => $user_id, 'session_id' => $session_id]);
    }

    public function insert(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'user_id' => 'nullable|integer',
                'product_id' => 'required|integer',

                'quantity' => 'required|integer',

            ]
        );
        $ipAddress = $request->ip();
        if (!ProductLineItem::where('ip_address', $ipAddress)->exists()) {
            $session = ProductLineItem::latest()->first();

            if ($session != null) {
                $session_id = $session['session_id'] + 1;
            } else {
                $session_id = 1;
            }
        } else {
            $session = ProductLineItem::where('ip_address', $ipAddress)->first();
            $session_id = $session['session_id'];
        }


        $product = $this->getProduct($request->product_id);
        $price = $this->calculatePrice($request->quantity, $product['total_price']);


        ProductLineItem::create(array_merge($request->all(), [
            'price' => $price,
            'session_id' => $session_id,
            'ip_address' => $ipAddress,
            'image' => $product['image'],
            'quantity' => $request->quantity,
            'delivery_charge' => $product['delivery_charge'],
            'name' => $product['product_name']
        ]));

        if ($request->user_id == null) {
            $user_id = 0;
        } else {
            $user_id = $request->user_id;
        }

        $productList = $this->productList();

        alert()->success('Added To Cart')->autoclose(3500);
        return view('index', ['productList' => $productList, 'success' => 'Added', 'user_id' => $user_id, 'session_id' => $session_id]);
    }

    protected function calculatePrice($quantity, $price)
    {
        $totalPrice = $quantity * $price;
        return $totalPrice;
    }
    public function update(Request $request, int $id)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'user_id' => 'nullable|integer',
                'product_id' => 'required|integer',

                'quantity' => 'required|integer',
                'session_id' => 'required|integer',

            ]
        );

        $data = ProductLineItem::find($id);
        $product = $this->getProduct($request->product_id);
        $price = $this->calculatePrice($request->quantity, $product['total_price']);
        $data->update(array_merge($request->all(), [
            'price' => $price,
            'image' => $product['image'],
            'quantity' => $request->quantity,
            'name' => $product['product_name']
        ]));
        return redirect('/viewCart');

        $cart = $this->list($request->session_id);

        return view('addToCart', ['cart' => $cart, 'user_id' => $request->user_id]);
    }

    public function delete(int $id, Request $request)
    {
        $data = ProductLineItem::find($id);
        $data->delete();
        return redirect('/viewCart');

        $cart = $this->list($request->session_id);

        alert()->success('Item Removed')->autoclose(3500);

        return view('addToCart', ['cart' => $cart, 'user_id' => $request->user_id, 'session_id' => $request->session_id]);
    }

    protected function getProduct($id)
    {
        $product = Product::find($id);
        return $product;
    }

    public function cart(Request $request)
    {
        $session_id = $request->session_id;
        if ($request->session_id == 0) {
            $ip_address = $request->ip();
            if (ProductLineItem::where('ip_address', $ip_address)->exists()) {
                $productLineItem = ProductLineItem::where('ip_address', $ip_address)->first();
                $session_id = $productLineItem['session_id'];
            }
        }

        $cart = $this->list($session_id);

        return view('addToCart', ['cart' => $cart, 'user_id' => $request->user_id, 'session_id' => $session_id]);
    }

    protected function productList()
    {
        $productList = Product::get(['id', 'product_name', 'total_price', 'image'])->toArray();
        return $productList;
    }

    public function index(Request $request)
    {
        Validator::make(
            $request->all(),
            [
                'user_id' => 'nullable|integer',
                'session_id' => 'required|integer'
            ]
        );

        $productList = $this->productList();
        alert()->success('Added To Cart')->autoclose(3500);

        return view('index', ['productList' => $productList]);
    }
}
