<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Razorpay\Api\Api;
use App\Models\Payment;
use Illuminate\Http\Request;
use App\Models\ProductLineItem;
use Illuminate\Support\Facades\Validator;

class PaymentController extends Controller
{
    public function verifyPaymentSignature(Request $request)
    {
        $validator = Validator::make(
            $request->all(),
            [
                'razorpay_signature' => 'required',
                'razorpay_payment_id' => 'required',
                'razorpay_order_id' => 'required',
            ]
        );
        $SignatureData = [];
        $SignatureData['razorpay_signature'] = $request->razorpay_signature;
        $SignatureData['razorpay_payment_id'] = $request->razorpay_payment_id;
        $SignatureData['razorpay_order_id'] = $request->razorpay_order_id;

        $api = new Api(env('RAZORPAY_KEY_ID'), env('RAZORPAY_KEY_SECRET'));

        $api->utility->verifyPaymentSignature($SignatureData);
        $payment = Payment::where('razorpayOrderId', $SignatureData['razorpay_order_id'])->first();

        $algo = "sha256";
        $data = $payment->razorpayOrderId . "|" . $SignatureData['razorpay_payment_id'];
        $key = env('RAZORPAY_KEY_SECRET');

        // check payment is success or not using SHA256 algorithm.
        $generatedSignature = hash_hmac($algo, $data, $key);

        if ($generatedSignature === $SignatureData['razorpay_signature']) {

            $fetchPayment = $api->payment->fetch($request->razorpay_payment_id);
            if ($fetchPayment) {
                $fetchData = [];
                $fetchData['paidAmount'] = $fetchPayment->amount / self::PAISA;
                $fetchData['paymentMethod'] = $fetchPayment->method;
                $fetchData['transactionId'] = $fetchPayment->id;
                $fetchData['paymentComments'] = json_encode($fetchPayment->toArray());

                $response = tap($payment)->update($fetchData);
                return $response->toArray();
            }
        } else {
            return false;
        }
    }

    public function razorPaySuccess(Request $request)
    {
        $order=Order::find($request->order_id);
        $product_line_items_id=$order['product_line_items_id'];
        foreach ($product_line_items_id as $id) {
            $cart = ProductLineItem::find($id);
            $cart->delete();
        }
        
        $data = [
            'payment_status' => 'success',
            'razorpay_payment_id' => $request->razorpay_payment_id,
            'amount' => $request->amount,
            'razorpay_signature'=>$request->razorpay_signature
        ];
        $payment = Payment::where('order_id',$request->order_id)->first();
        $payment->update($data);

        return view('thankyou');
    }
}
