
<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products.create')); ?>" method="post" enctype="multipart/form-data" style="align-items: flex-start;
    justify-content: center;
    width: 80%;
    height: 500px;
    display: flex;
">
    <?php echo csrf_field(); ?>

    <div id="" class="col-sm-12" style="background-color: #fff;width:95%;margin-top:15px">
        <div class="">
            <?php if(!empty($errors)): ?>
            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span style="color: red;font-size: 16px;"><?php echo e($error); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(!empty($success)): ?>
            <span style="color: green;font-size: 16px;"><?php echo e($success); ?></span>
            <?php endif; ?>
            <div class="">

                <div class="">
                    <div class="mb-3">
                        <label class="form-label">Product Name</label>
                        <input type="text" name="product_name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="form-label">Category</label>
                        <select name="category" id="" class="form-control" required>
                            <option value="">Select</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category['id']); ?>"><?php echo e($category['category_name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Enter Total Delivery Time(in days)</label>
                        <input type="number" name="total_delivery_time" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Product Price</label>
                        <input type="number" name="product_cost" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tax</label>
                        <input type="number" name="tax" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Delivery Charge</label>
                        <input type="number" name="delivery_charge" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Product Description</label>
                        <input type="text" name="description" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Product Image</label>
                        <input type="file" name="image" class="form-control" required>
                    </div>

                </div>
                <div class="" style="margin: 10px;">

                    <button type="submit" class="btn btn-primary">Save</button>


                </div>
            </div>

        </div>
    </div>
</form>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/adminDashboard/createProduct.blade.php ENDPATH**/ ?>