<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">
  <title>Ecommerce Website</title>
  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link href="<?php echo e(asset('css/payment.css')); ?>" rel="stylesheet" type="text/css">
  <script src="https://kit.fontawesome.com/1b2cfc15df.js" crossorigin="anonymous"></script>


</head>

<body class="sub_page">
  <div class="hero_area">


    <div id="app" v-cloak>

      <div class="container wrapper">

        <div class="row">
          <div class="col s12 m6">
            <div class="card" id="step-1">
              <div class="card-content" style="padding: 24px;
    border-radius: 0 0 2px 2px;">

                <div class="row info">
                  <div class="col s12 m6">
                    <p><b>Billing address:</b></p>
                    <p><?php echo e($userData['delivery_address']); ?></p>
                    <p><?php echo e($userData['phone']); ?></p>
                  </div>

                </div>


              </div>
            </div>


          </div>



          <div class="col s12 m6">
            <div class="card" id="step-4" v-cloak>
              <div class="card-content" style="padding: 24px;
    border-radius: 0 0 2px 2px;">
                <span class="card-title activator grey-text text-darken-4" style="display: block;
    line-height: 32px;
    margin-bottom: 8px;"><b>Order summary</b></span>

                <span><b><?php echo e($order['items_count']); ?> items</b></span>
                <?php $__currentLoopData = $order['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <ul class="collection" style="margin: 0.5rem 0 1rem 0;
    border: 1px solid #e0e0e0;
    border-radius: 2px;
    position: relative;">
                  <li class="collection-item avatar" ref="item-1" v-for="(product, index) in products" style="padding: 10px 20px;padding: 10px 20px;
    padding-left: 72px;
    position: relative;
    list-style-type: none;">
                    <img src="<?php echo e(asset($item['image'])); ?>" alt="" class="circle" style="position: absolute;
    width: 42px;
    height: 42px;
    overflow: hidden;
    left: 15px;
    display: inline-block;
    vertical-align: middle;
    border-radius: 50%;">
                    <div class="row">
                      <div class="col s12 l4">
                        <span class="title"><?php echo e($item['name']); ?></span>
                        <p>Rs. <?php echo e($item['price']); ?></p>
                      </div>

                    </div>
                  </li>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <ul>
                  <li v-if="shipping" style="list-style-type: none;">
                    <span><b>Shipping Charge</b> </span>
                    <span class="right" style="float: right !important;">Rs. <?php echo e($order['total_delivery_charge']); ?></span>
                  </li>
                 <!--  <li v-if="taxTotal" style="list-style-type: none;">
                    <span><b>TAX</b></span>
                    <span class="right" style="float: right !important;">$57.75</span>
                  </li> -->
                </ul>
              </div>
              <div class="card-action" v-if="basketTotal" style="background-color: inherit;
    border-top: 1px solid rgba(160,160,160,0.2);
    position: relative;
    padding: 16px 24px;">
                <span><b>Total</b></span>
                <span class="right" style="float: right !important;"><b>Rs. <?php echo e($order['order_total_amount']); ?></b></span>
              </div>
              <div class="card-action" style="background-color: inherit;
    border-top: 1px solid rgba(160,160,160,0.2);
    position: relative;
    padding: 16px 24px;">
                <span class="card-title activator grey-text text-darken-4"><b>Payment</b></span>
                <p class="payment-info">Please choose payment method. </p>


                <button id="rzp-button1" class="mobilepay" style="background-color: blue;
    border: 1px solid #blue;
    color: #ffffff;
    display: inline-block;
    padding: 8px 15px;
    border-radius: 30px;
    width: 165px;
    text-align: center;
    -webkit-transition: all .3s;
    transition: all .3s;
    margin: 5px 0;">
                  Razor Pay
                </button>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>


</body>

</html>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  var SITEURL = '<?php echo e(URL::to('')); ?>';
  var options = {
    "key": "<?php echo e(env('RAZORPAY_KEY_ID')); ?>", // Enter the Key ID generated from the Dashboard    
    "amount": "<?php echo e($order['order_total_amount']); ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise    
    "currency": "INR",
    "name": "Ecommerce Web",
    "description": "Test Transaction",
    "image": "https://example.com/your_logo",
    "order_id": "<?php echo e($razorpayOrderId); ?>", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1   
    // "callback_url": "https://eneqd3r9zrjok.x.pipedream.net/",
    "handler": function(response) {
      window.location.href = SITEURL + '/' + 'paysuccess?razorpay_payment_id=' + response.razorpay_payment_id + '&razorpay_signature=' + response.razorpay_signature + '&amount=' + "<?php echo e($order['order_total_amount']); ?>" + '&order_id=' + "<?php echo e($order['id']); ?>";
    },
    "prefill": {
      // "name": "Gaurav Kumar",
      //  "email": "gaurav.kumar@example.com",
      //  "contact": "9999999999"
    },
    "notes": {
      "address": "Razorpay Corporate Office"
    },
    "theme": {
      "color": "#3399cc"
    }
  };
  var rzp1 = new Razorpay(options);
  document.getElementById('rzp-button1').onclick = function(e) {
    console.log(options);
    rzp1.open();
    e.preventDefault();
  }
</script><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/payment.blade.php ENDPATH**/ ?>