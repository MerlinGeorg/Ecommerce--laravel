<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">
  <title>Ecommerce Website</title>
  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link href="<?php echo e(asset('css/payment.css')); ?>" rel="stylesheet" type="text/css">
  <script src="https://kit.fontawesome.com/1b2cfc15df.js" crossorigin="anonymous"></script>

</head>

<body class="sub_page">
  <div class="hero_area">

    <div id="app" v-cloak>

      <div class="container wrapper">

        <div class="row">
          <div class="col s12 m6">
            <div class="card" id="step-1">
              <div class="card-content" style="padding: 24px;
    border-radius: 0 0 2px 2px;">
                <span class="card-title activator grey-text text-darken-4"><b>Add/Edit Delivery Address</b></span>
                <div class="row m-top-15">
                  <form class="col s12" action="<?php echo e(url('updateDeliveryAddress',$user['id'])); ?>" method="POST">
                    <div class="row">

                      <input type="hidden" name="order_id" value="<?php echo e($order_id); ?>">
                    </div>
                    <?php if(!empty($user['delivery_address'])): ?>
                    <div class="row m-top-15">
                      <div class="input-field col s12 autocomplete-container">
                        <label for="dawa-autocomplete-input">Full address</label>

                        <input type="text" name="delivery_address" value="<?php echo e($user['delivery_address']); ?>">

                      </div>
                    </div>
                    <div class="row">

                      <div class="input-field col s12 l6 m-top-15">
                        <label for="phone">Phone
                        </label>
                        <input id="phone" name="phone" type="number" value="<?php echo e($user['phone']); ?>" class="validate" autocomplete="tel">

                      </div>
                    </div>
                    <?php else: ?>
                    <div class="row m-top-15">
                      <div class="input-field col s12 autocomplete-container">
                        <label for="dawa-autocomplete-input">Full address</label>

                        <input type="text" name="delivery_address" required>

                      </div>
                    </div>
                    <div class="row">

                      <div class="input-field col s12 l6 m-top-15">
                        <label for="phone">Phone
                        </label>
                        <input id="phone" name="phone" type="number" class="validate" autocomplete="tel" required>

                      </div>
                    </div>
                    <?php endif; ?>
                    <button class="mobilepay" style="background-color: blue;
    border: 1px solid #blue;
    color: #ffffff;
    display: inline-block;
    padding: 8px 15px;
    border-radius: 30px;
    width: 165px;
    text-align: center;
    -webkit-transition: all .3s;
    transition: all .3s;
    margin: 5px 0;">
                      Save
                    </button>
                  </form>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </div>
  </div>
</body>

</html><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/deliveryAddress.blade.php ENDPATH**/ ?>