
<?php $__env->startSection('content'); ?>

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">User Id</th>
        <th scope="col">Order Total </th>
        <!-- <th scope="col">Total Delivery Time(days)</th> -->
        <th scope="col">Delivery Charge</th>
        <th scope="col">Order Status</th>
        <th scope="col">Items Count</th>
        <th scope="col">Order created time</th>
      </tr>
    </thead>
    <tbody>



      <?php if(!empty($orderList)): ?>

      <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>

        <td><?php echo e($order['user_id']); ?></td>
        <td>Rs. <?php echo e($order['order_total_amount']); ?></td>
        <td>Rs. <?php echo e($order['total_delivery_charge']); ?></td>
        <td><?php echo e($order['order_status']); ?></td>
        <td><?php echo e($order['items_count']); ?></td>
        <td><?php echo e($order['created_at']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/adminDashboard/orderList.blade.php ENDPATH**/ ?>