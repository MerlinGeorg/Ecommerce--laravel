
<?php $__env->startSection('content'); ?>

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">Product Name</th>
        <th scope="col">Category</th>
        <th scope="col">Total Delivery Time(days)</th>
        <th scope="col">Product Price</th>
        <th scope="col">Tax</th>
        <th scope="col">Delivery Charge</th>
        <th scope="col">Product Description</th>
        <th scope="col">Product Image</th>
      </tr>
    </thead>
    <tbody>


      <?php if(!empty($productList)): ?>

      <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($product['product_name']); ?></td>
        <td><?php echo e($product['product_category']['category_name']); ?></td>
        <td><?php echo e($product['total_delivery_time']); ?></td>
        <td><?php echo e($product['product_cost']); ?></td>
        <td><?php echo e($product['tax']); ?></td>
        <td><?php echo e($product['delivery_charge']); ?></td>
        <td><?php echo e($product['description']); ?></td>
        <td><?php echo e($product['image']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/adminDashboard/productList.blade.php ENDPATH**/ ?>