<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Or Login</title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf"
    crossorigin="anonymous">
    <link href="<?php echo asset('css/account.css')?>" rel="stylesheet" type="text/css">
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
    

            <?php if($errors): ?>
            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span style="color: red;font-size: 16px;"><?php echo e($error); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if(!empty($success)): ?>
            <span style="color: green;font-size: 16px;"><?php echo e($success); ?></span>
            <?php endif; ?>
<div class="small-container" id="small-container">
        <div class="form-container sign-up-container">
            <form action="<?php echo e(route('signup')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                <h1>Create Account</h1>
              
                <span>or use your email for registration</span>
                <input type="text" name="name" placeholder="Name" />
                <input type="email" name="email" placeholder="Email" />
                <input type="password" name="password" placeholder="Password" />
                <input type="password" name="password_confirmation" placeholder="confirmPassword" />
                <button type="submit">Sign Up</button>
            </form>
        </div>
        <div class="form-container sign-in-container">
            <form action="<?php echo e(url('/signin')); ?>" method="POST">
                <?php echo csrf_field(); ?>
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                <h1>Sign in</h1>
               
                <span>or use your account</span>
                <input type="email" placeholder="Email" name="email" />
                <input type="password" placeholder="Password" name="password" />
                <button type="submit">Sign In</button>
            </form>
            
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button onclick=""  class="ghost" id="signIn">Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start journey with us</p>
                    <button onclick=""  class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
    </div>



    </body>
    <script src="<?php echo asset('js/account.js')?>" type="text/javascript"></script>
</html><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/account.blade.php ENDPATH**/ ?>