
<?php $__env->startSection('content'); ?>

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">#</th>
        <th scope="col">Customer Name</th>
        <th scope="col">Email</th>
      </tr>
    </thead>
    <tbody>


      <?php if(!empty($customerList)): ?>

      <?php $__currentLoopData = $customerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($users['id']); ?></td>
        <td><?php echo e($users['name']); ?></td>
        <td><?php echo e($users['email']); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <?php else: ?>
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/adminDashboard/customerList.blade.php ENDPATH**/ ?>