<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">
  <title>Ecommerce Website</title>
  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <link href="<?php echo e(asset('css/singleProduct.css')); ?>" rel="stylesheet" type="text/css">

  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="sub_page">
  <div class="hero_area">


    <div class="small-container single-product">
      <div class="row">
        <div class="col-2">
          <img src="<?php echo e(asset($product['image'])); ?>" alt="" width="100%" id="ProductImg" />


        </div>
        <div class="col-2">
          <p>Category: Home / <?php echo e($product['product_category']['category_name']); ?></p>
          <h1><?php echo e($product['product_name']); ?></h1>
          <h4>₹<?php echo e($product['total_price']); ?> (including tax)</h4>
          <h4>Tax: <?php echo e($product['tax']); ?></h4>
          <h4>Delivery Charge: <?php echo e($product['delivery_charge']); ?></h4>

          <h3>Product Details</h3>
          <br />
          <p>
            <?php echo e($product['description']); ?>

          </p>
        </div>
      </div>
    </div><?php /**PATH C:\wamp\www\Laravel\Coding Tests\ecommerce\resources\views/singleProduct.blade.php ENDPATH**/ ?>