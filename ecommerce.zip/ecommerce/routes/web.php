<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProductLineItemController;
use App\Http\Controllers\RazorpayPaymentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::group(['middleware' => ['web']], function () {
Route::get('/',[AuthController::class,'index']);
//});
Route::post('/search', [ProductController::class,'productSearch']);

Route::get('/admin',[AdminController::class,'index']);

Route::get('/account',[AuthController::class,'account']);

Route::post('/signin', [AuthController::class,'login']);

Route::post('/userProfile', [AuthController::class,'getUserProfile']);

Route::get('/create',[ProductController::class,'productCreateForm']);

Route::post('/cart',[ProductLineItemController::class,'cart']);
Route::post('addToCart',[ProductLineItemController::class,'insert']);

Route::post('/updateCart/{id}', [ProductLineItemController::class,'update']);

Route::post('/placeOrder', [OrderController::class,'insert']);

Route::get('/viewCart',[ProductLineItemController::class,'viewCart']);
Route::get('/singleProduct/{id}',[ProductController::class,'getSingleProduct']);

Route::get('paysuccess', [PaymentController::class, 'razorPaySuccess']);
Route::get('paymentForm/{id}', [AuthController::class, 'paymentPage']);

Route::post('updateDeliveryAddress/{id}', [App\Http\Controllers\AuthController::class,'update']);