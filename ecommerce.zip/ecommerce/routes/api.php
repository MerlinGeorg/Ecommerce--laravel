<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/ 

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('signup', 'App\Http\Controllers\AuthController@signup')->name('signup');

Route::get('listProducts', 'App\Http\Controllers\ProductController@list')->name('products.list');
Route::post('addProducts', 'App\Http\Controllers\ProductController@insert')->name('products.create');
Route::get('listCustomers', 'App\Http\Controllers\AuthController@list')->name('customers.list');
Route::get('listOrders', 'App\Http\Controllers\OrderController@list')->name('orders.list');


Route::delete('cart/{id}', 'App\Http\Controllers\ProductLineItemController@delete')->name('cart.delete');

//Route::post('signout', 'App\Http\Controllers\AuthController@logout')->name('signout');