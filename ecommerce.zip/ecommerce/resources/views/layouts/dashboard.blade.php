<!DOCTYPE html>
<html lang="en">

<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <meta name="_token" content="{!! csrf_token() !!}" /> -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://kit.fontawesome.com/1b2cfc15df.js" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    /* Set height of the grid so .sidenav can be 100% (adjust as needed) */


    /* Set gray background color and 100% height */
    .sidenav {
      background-color: #183153;
      height: 100%;
    }

    ul {
      color: white;
    }

    .nav>li>a {
      color: white;
    }

    .row.content {
      height: 700px;
    }

    #list:hover {
      background-color: black;
    }

    a {
      cursor: pointer;
    }

    /* On small screens, set height to 'auto' for the grid */
    @media screen and (max-width: 767px) {
      .row.content {
        height: auto;
      }

    }
  </style>
  @stack('head')
</head>

<body>

  <nav class="navbar navbar-inverse visible-xs">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav">

        </ul>
      </div>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="row content">
      <div class="col-sm-3 sidenav hidden-xs" style="width: 20%;">
        <h2 style="color: #fff;">Admin</h2>
        <ul class="nav nav-pills nav-stacked">

          <li>
            <!-- <a href="">Forms</a> -->
            <ul>
              <li>
                <a href="{{url('/create')}}" style="color: #fff;">
                  Add Products</a>
              </li>
              <li onclick="location.href='{{route('products.list')}}'" style="cursor: pointer;">
                List Products
              </li>
              <li onclick="location.href='{{route('customers.list')}}'" style="cursor: pointer;">
                List Customers
              </li>
              <li onclick="location.href='{{route('orders.list')}}'" style="cursor: pointer;">
                List Orders
              </li>
            </ul>
          </li>

        </ul><br>
      </div>

      <br>

      <div class="col-sm-9" style="width: 80%;">

        <div class="row" style="background-color: #e4e9f0;align-items: center;justify-content:center;display:flex;min-height: 600px;margin-left:20px;margin-right:10px">
          @yield('content')

        </div>

      </div>
    </div>
  </div>

</body>

</html>