<!DOCTYPE html>
<html>

<head>
   <!-- Basic -->
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <!-- Site Metas -->
   <meta name="keywords" content="" />
   <meta name="description" content="" />
   <meta name="author" content="" />
   <link rel="shortcut icon" href="images/favicon.png" type="">
   <title>Ecommerce Website</title>
   <!-- bootstrap core css -->
   <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
   <!-- font awesome style -->
   <link href="css/font-awesome.min.css" rel="stylesheet" />
   <!-- Custom styles for this template -->
   <link href="css/style.css" rel="stylesheet" />
   <!-- responsive style -->
   <link href="css/responsive.css" rel="stylesheet" />
   <script src="https://kit.fontawesome.com/1b2cfc15df.js" crossorigin="anonymous"></script>

   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
</head>

<body class="sub_page">
@if(empty($session_id))
                        @php
                        $session_id=0
                        @endphp
                        @endif
   <div class="hero_area">
      <!-- header section strats -->
      <header class="header_section">
         <div class="container">
            <nav class="navbar navbar-expand-lg custom_nav-container ">
               <a class="navbar-brand" href="index.html"><img width="250" src="images/logo.png" alt="#" /></a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class=""> </span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav">
                     <li class="nav-item">

                        <a class="nav-link" href="{{url('/')}}">Home <span class="sr-only">(current)</span></a>
                     </li>

                     @if(empty($user_id))
                     <li class="nav-item  active">
                        <a class="nav-link " href="{{url('/account')}}"> <span class="nav-label">Signup or Login <span class="caret"></span></a>

                     </li>
                     @endif

                     <li class="nav-item">

                        <form action="{{url('/userProfile')}}" method="POST">
                           @if(!empty($access_token))
                           <input type="hidden" name="access_token" value="{{$access_token}}">
                           <input type="hidden" name="user_id" value="{{$user_id}}">
                           @endif
                           <button class="nav-link" type="submit" style="border: none;background: white;">Profile</button>
                        </form>

                     </li>

                     <li class="nav-item">

                        <form action="{{url('/cart')}}" method="POST" target="_blank">

                           <input type="hidden" name="session_id" value="{{$session_id}}">
                           <input type="hidden" name="ip_address" value="ip">
                           @if(empty($user_id))
                           <input type="hidden" name="user_id" value="">
                           @else
                           <input type="hidden" name="user_id" value="{{$user_id}}">
                           @endif

                           <button type="submit" style="border: none;background: white;"><img src="https://i.ibb.co/PNjjx3y/cart.png" alt="" width="30px" height="30px" /></button>

                        </form>

                     </li>

                  </ul>
               </div>
            </nav>
         </div>
      </header>
      @include('sweet::alert')


   </div>

   <!-- product section -->
   <section class="product_section layout_padding">
      <div class="container">
         <div class="heading_container heading_center">
            <h2>
               Our <span>products</span>

            </h2>
            <div>
               <div style="float: left;">
                  <form class="form-inline" action="{{url('/search')}}" method="POST">
                     @csrf
                     <input type="hidden" name="_token" value="{!! csrf_token() !!}">
                     <button class="btn  my-2 my-sm-0 nav_search-btn" type="submit">
                        <i class="fa fa-search" aria-hidden="true" style="margin-right: 35px;"></i></button>
               </div>
               <div style="float: right;"> <input type="text" name="product_name" class="form-control" required></div>
               <input type="hidden" name="session_id" value="{{$session_id}}">
            </form>
            </div>

            <div class="row">

               @if(empty($searchProduct))
               @if(!empty($productList))
               @foreach($productList as $product)

               <div class="col-sm-6 col-md-4 col-lg-4" style="max-width: 50%;">
                  <div class="box">
                     <form action="{{url('addToCart')}}" method="POST">


                        @if(!empty($user_id))
                        <input type="hidden" name="user_id" value="{{$user_id}}">
                        @endif
                        <div class="option_container">
                           <div class="options">
                              <a href="{{url('/singleProduct',$product['id'])}}" class="option1">
                                 View Product
                              </a>
                              <input type="hidden" name="product_id" value="{{$product['id']}}">
                              <input type="hidden" name="quantity" value="1">

                              <button type="submit" class="option2" style="display: inline-block;
    padding: 8px 15px;
    border-radius: 30px;
    width: 165px;">
                                 Add To Cart
                              </button>
                           </div>
                        </div>
                        <div class="img-box">
                           <img src="{{$product['image']}}" alt="">
                        </div>
                        <div class="detail-box">
                           <h5>
                              {{$product['product_name']}}
                           </h5>
                           <h6>
                              Rs. {{$product['total_price']}}
                           </h6>
                        </div>
                     </form>
                  </div>
               </div>

               @endforeach
               @else
              <p>
                  <!-- <div class="box"> -->
               No Products Available At The Moment
                  <!-- </div> -->
                  </p>
               @endif
               @else
               @foreach($searchProduct as $product)

               <div class="col-sm-6 col-md-4 col-lg-4">
                  <div class="box">
                     <form action="{{url('addToCart')}}" method="POST">


                        @if(!empty($user_id))
                        <input type="hidden" name="user_id" value="{{$user_id}}">
                        @endif
                        <div class="option_container">
                           <div class="options">
                              <a href="" class="option1">
                                 View Product
                              </a>
                              <input type="hidden" name="product_id" value="{{$product['id']}}">
                              <input type="hidden" name="quantity" value="1">

                              <button type="submit" class="option2">
                                 Add To Cart
                              </button>
                           </div>
                        </div>
                        <div class="img-box">
                           <img src="{{$product['image']}}" alt="">
                        </div>
                        <div class="detail-box">
                           <h5>
                              {{$product['product_name']}}
                           </h5>
                           <h6>
                              Rs. {{$product['total_price']}}
                           </h6>
                        </div>
                     </form>
                  </div>
               </div>

               @endforeach
               @endif

            </div>
            </div>
         </div>
   </section>
   <!-- footer section -->
   <footer class="footer_section">
      <div class="container">
         <div class="row">
            <div class="col-md-4 footer-col">
               <div class="footer_contact">
                  <h4>
                     Reach at..
                  </h4>
                  <div class="contact_link_box">
                     <a href="">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <span>
                           Location
                        </span>
                     </a>
                     <a href="">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                        <span>
                           Call +01 1234567890
                        </span>
                     </a>
                     <a href="">
                        <i class="fa fa-envelope" aria-hidden="true"></i>
                        <span>
                           demo@gmail.com
                        </span>
                     </a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 footer-col">
               <div class="footer_detail">
                  <a href="index.html" class="footer-logo">
                     Famms
                  </a>
                  <p>
                     Necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with
                  </p>
                  <div class="footer_social">
                     <a href="">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-pinterest" aria-hidden="true"></i>
                     </a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 footer-col">
               <div class="map_container">
                  <div class="map">
                     <div id="googleMap"></div>
                  </div>
               </div>
            </div>
         </div>
         <div class="footer-info">
            <div class="col-lg-7 mx-auto px-0">
               <p>
                  &copy; <span id="displayYear"></span> All Rights Reserved By
                  <a href="https://html.design/">Free Html Templates</a>
               </p>
            </div>
         </div>
      </div>
   </footer>
   <!-- footer section -->
   <!-- jQery -->
   <script src="js/jquery-3.4.1.min.js"></script>
   <!-- popper js -->
   <script src="js/popper.min.js"></script>
   <!-- bootstrap js -->
   <script src="js/bootstrap.js"></script>
   <!-- custom js -->
   <script src="js/custom.js"></script>

</body>

</html>