<!DOCTYPE html>
<html>

<head>
   <!-- Basic -->
   <meta charset="utf-8" />
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <!-- Mobile Metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
   <!-- Site Metas -->
   <meta name="keywords" content="" />
   <meta name="description" content="" />
   <meta name="author" content="" />
   <link rel="shortcut icon" href="images/favicon.png" type="">
   <title>Ecommerce Website</title>
   <!-- bootstrap core css -->
   <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
   <!-- font awesome style -->
   <link href="css/font-awesome.min.css" rel="stylesheet" />
   <!-- Custom styles for this template -->
   <link href="css/style.css" rel="stylesheet" />
   <!-- responsive style -->
   <link href="css/responsive.css" rel="stylesheet" />
   <script src="https://kit.fontawesome.com/1b2cfc15df.js" crossorigin="anonymous"></script>
   <link href="{{asset('css/addToCart.css')}}" rel="stylesheet" type="text/css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
   <style>
       
        /* img {
            width: 50px;
        } */

        table {
            margin: 10rem;
            border-collapse: collapse;

            font-size: 1.2rem;
        }

        th,
        td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>

<body class="sub_page">

   <div class="hero_area">

      <!-- header section strats -->
      <header class="header_section">
         <div class="container">
            <nav class="navbar navbar-expand-lg custom_nav-container ">
               <a class="navbar-brand" href="index.html"><img width="250" src="images/logo.png" alt="#" /></a>
               <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class=""> </span>
               </button>
               <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav">
                     <li class="nav-item">
                        @if(empty($session_id))
                        @php
                        $session_id=0
                        @endphp
                        @endif
                        @if(empty($user_id))
                        @php
                        $user_id=0
                        @endphp
                        @endif
                        <form action="{{url('/')}}" method="GET">
                           <input type="hidden" name="session_id" value="{{$session_id}}">
                           <button class="nav-link" href="{{url('/')}}">Home <span class="sr-only">(current)</span></button>
                        </form>
                     </li>

                  </ul>
               </div>
            </nav>
         </div>
      </header>

      <div id="app">

         <!-- <div id="cart">
            <div id="head">
               <h3>Shopping Cart</h3>
               <div id="price">Price</div>
               <div id="quantity">Quantity</div>
               <div id="total">Total</div>
            </div>
         </div>
 -->
        

         <!-- <div id="buy-box"> -->
         <table class="shoppingcart">
         @php
         $product_line_items_id=[]
         @endphp
          <tr>
            <th>Shopping Cart</th>
            <th></th>
            <th>Price</th>
            <th>Quantity</th>
            <!-- <th></th> -->
            <th>Total</th>
        </tr> 

      

            @php
            $sum=0
            @endphp
            @if(!empty($cart))

            @foreach($cart as $product)


   
       
        <tr>
        <form action="{{url('/updateCart',$product['id'])}}" method="POST">

@php
$product_line_items_id[]=$product['id']
@endphp
            <td><img src="{{$product['image']}}" style="height: 100px;" /></td>
            <td>{{$product['products']['product_name']}}</td>
            <td>{{$product['products']['total_price']}}</td>

            <input type="hidden" name="product_id" value="{{$product['product_id']}}">
                  <input type="hidden" id="session_id" name="session_id" value="{{$product['session_id']}}">
                  <input type="hidden" name="user_id" value="{{$user_id}}">

            <td><input type="number" name="quantity" value="{{$product['quantity']}}" style="width: 45%;height:3%"></td>
            <td>{{$product['price']}}</td>
            <td><button type="submit" class="option2" style="border: none;background: white;color: deeppink;">Add To Cart</button></td>
            @php
                  $sum+=$product['price']
                  @endphp

               </form>
               @include('sweet::alert')
               <form action="{{route('cart.delete',$product['id'])}}" method="POST">
                  @method('delete')
                  <input type="hidden" name="session_id" value="{{$product['session_id']}}">
                  <input type="hidden" name="user_id" value="{{$user_id}}">
       <td><button type="submit" class="option2" style="border: none;background: white;color: deeppink;">Remove</button></td>
       </form>
      </tr>
      @endforeach
            @else
            <tr><td> No items in cart</td></tr>
            @endif

    </table>
    <!-- </div> -->

         <form action="{{url('/placeOrder')}}" method="POST">
            <div style="margin: 10px;">
               <h5>Sum: Rs. {{$sum}}</h5>

               @if(empty($user_id))
               @if(!empty($errors))

               <span style="color: red;font-size: 16px;">{{$errors}}</span>

               @endif
               @endif

               <div class="options">
                  @foreach($product_line_items_id as $id)
                  <input type="hidden" name="product_line_items_id[]" value="{{$id}}">
                  @endforeach


                  @if(!empty($cart))


                  <input type="hidden" name="session_id" value="{{$product['session_id']}}">
                  <input type="hidden" name="user_id" value="{{$user_id}}">

                  <button type="submit" class="option1" style="background-color: #f7444e;
    border: 1px solid #f7444e;
    color: #ffffff;
    display: inline-block;
    padding: 8px 15px;
    border-radius: 30px;
    width: 165px;
    text-align: center;
    -webkit-transition: all .3s;
    transition: all .3s;
    margin: 5px 0;float: right;">
                     Proceed To Buy
                  </button>


               </div>
               @endif

            </div>
         </form>
     </div> 
   </div>


   <!-- footer section -->
   <footer class="footer_section">
      <div class="container">
         <div class="row">
            <div class="col-md-4 footer-col">
               <div class="footer_contact">
                  <h4>
                     Reach at..
                  </h4>
                  <div class="contact_link_box">
                     <a href="">
                        <i class="fa fa-map-marker" aria-hidden="true"></i>
                        <span>
                           Location
                        </span>
                     </a>
                     <a href="">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                        <span>
                           Call +01 1234567890
                        </span>
                     </a>
                     <a href="">
                        <i class="fa fa-envelope" aria-hidden="true"></i>
                        <span>
                           demo@gmail.com
                        </span>
                     </a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 footer-col">
               <div class="footer_detail">
                  <a href="index.html" class="footer-logo">
                     Famms
                  </a>
                  <p>
                     Necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with
                  </p>
                  <div class="footer_social">
                     <a href="">
                        <i class="fa fa-facebook" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-twitter" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-linkedin" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-instagram" aria-hidden="true"></i>
                     </a>
                     <a href="">
                        <i class="fa fa-pinterest" aria-hidden="true"></i>
                     </a>
                  </div>
               </div>
            </div>
            <div class="col-md-4 footer-col">
               <div class="map_container">
                  <div class="map">
                     <div id="googleMap"></div>
                  </div>
               </div>
            </div>
         </div>
         <div class="footer-info">
            <div class="col-lg-7 mx-auto px-0">
               <p>
                  &copy; <span id="displayYear"></span> All Rights Reserved By
                  <a href="https://html.design/">Abc</a>
               </p>
            </div>
         </div>
      </div>
   </footer>
   <!-- footer section -->
   <!-- jQery -->
   <script src="js/jquery-3.4.1.min.js"></script>
   <!-- popper js -->
   <script src="js/popper.min.js"></script>
   <!-- bootstrap js -->
   <script src="js/bootstrap.js"></script>
   <!-- custom js -->
   <script src="js/custom.js"></script>

</body>

</html>
<script type="text/javascript">
   function buyitems() {
      var x = document.getElementById("buy")
      x.style.display = "block";
   }
</script>