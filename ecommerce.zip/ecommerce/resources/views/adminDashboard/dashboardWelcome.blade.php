@extends('layouts.dashboard')

@section('content')
      <span style="font-size: 4rem;">Welcome</span>
    @endsection('content')

      
