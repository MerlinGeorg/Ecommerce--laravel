@extends('layouts.dashboard')
@section('content')

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">#</th>
        <th scope="col">Customer Name</th>
        <th scope="col">Email</th>
      </tr>
    </thead>
    <tbody>


      @if(!empty($customerList))

      @foreach($customerList as $users)

      <tr>
        <td>{{$users['id']}}</td>
        <td>{{$users['name']}}</td>
        <td>{{$users['email']}}</td>
      </tr>
      @endforeach

      @else
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      @endif
    </tbody>
  </table>

</div>
@endsection