@extends('layouts.dashboard')
@section('content')

<form action="{{route('products.create')}}" method="post" enctype="multipart/form-data" style="align-items: flex-start;
    justify-content: center;
    width: 80%;
    height: 500px;
    display: flex;
">
    @csrf

    <div id="" class="col-sm-12" style="background-color: #fff;width:95%;margin-top:15px">
        <div class="">
            @if(!empty($errors))
            @foreach($errors as $error)
            <span style="color: red;font-size: 16px;">{{$error}}</span>
            @endforeach
            @endif
            @if(!empty($success))
            <span style="color: green;font-size: 16px;">{{$success}}</span>
            @endif
            <div class="">

                <div class="">
                    <div class="mb-3">
                        <label class="form-label">Product Name</label>
                        <input type="text" name="product_name" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label for="" class="form-label">Category</label>
                        <select name="category" id="" class="form-control" required>
                            <option value="">Select</option>
                            @foreach($categories as $category)
                            <option value="{{$category['id']}}">{{$category['category_name']}}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Enter Total Delivery Time(in days)</label>
                        <input type="number" name="total_delivery_time" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Product Price</label>
                        <input type="number" name="product_cost" class="form-control" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tax</label>
                        <input type="number" name="tax" class="form-control">
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Delivery Charge</label>
                        <input type="number" name="delivery_charge" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Product Description</label>
                        <input type="text" name="description" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Product Image</label>
                        <input type="file" name="image" class="form-control" required>
                    </div>

                </div>
                <div class="" style="margin: 10px;">

                    <button type="submit" class="btn btn-primary">Save</button>


                </div>
            </div>

        </div>
    </div>
</form>



@endsection