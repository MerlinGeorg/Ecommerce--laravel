@extends('layouts.dashboard')
@section('content')

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">Product Name</th>
        <th scope="col">Category</th>
        <th scope="col">Total Delivery Time(days)</th>
        <th scope="col">Product Price</th>
        <th scope="col">Tax</th>
        <th scope="col">Delivery Charge</th>
        <th scope="col">Product Description</th>
        <th scope="col">Product Image</th>
      </tr>
    </thead>
    <tbody>


      @if(!empty($productList))

      @foreach($productList as $product)

      <tr>
        <td>{{$product['product_name']}}</td>
        <td>{{$product['product_category']['category_name']}}</td>
        <td>{{$product['total_delivery_time']}}</td>
        <td>{{$product['product_cost']}}</td>
        <td>{{$product['tax']}}</td>
        <td>{{$product['delivery_charge']}}</td>
        <td>{{$product['description']}}</td>
        <td>{{$product['image']}}</td>
      </tr>
      @endforeach

      @else
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      @endif
    </tbody>
  </table>
</div>

@endsection