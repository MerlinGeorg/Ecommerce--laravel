@extends('layouts.dashboard')
@section('content')

<div style="background-color: #fff;width: 90%;">
  <table class="table">
    <thead>
      <tr>

        <th scope="col">User Id</th>
        <th scope="col">Order Total </th>
        <!-- <th scope="col">Total Delivery Time(days)</th> -->
        <th scope="col">Delivery Charge</th>
        <th scope="col">Order Status</th>
        <th scope="col">Items Count</th>
        <th scope="col">Order created time</th>
      </tr>
    </thead>
    <tbody>



      @if(!empty($orderList))

      @foreach($orderList as $order)

      <tr>

        <td>{{$order['user_id']}}</td>
        <td>Rs. {{$order['order_total_amount']}}</td>
        <td>Rs. {{$order['total_delivery_charge']}}</td>
        <td>{{$order['order_status']}}</td>
        <td>{{$order['items_count']}}</td>
        <td>{{$order['created_at']}}</td>
      </tr>
      @endforeach

      @else
      <tr>
        <td style="align-items: center;"><b>No Records Available</b></td>
      </tr>
      @endif
    </tbody>
  </table>
</div>

@endsection