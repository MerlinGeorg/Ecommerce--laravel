@extends('layouts.app')
@push('styles')
<link href="{{asset('css/userProfile.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('css/viewMyOrders.css')}}" rel="stylesheet" type="text/css">
@endpush
@section('content')
</div>
<!-- inner page section -->
<section class="inner_page_head">
   <div class="container_fuild">
      <div class="row">
         <div class="col-md-12">
            <div class="full">
               <h3>Profile</h3>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- end inner page section -->

<div class="container">
   <div class="row profile">
      <div class="col-md-3">
         <div class="profile-sidebar">
            <!-- SIDEBAR USERPIC -->
            <div class="profile-userpic">

            </div>
            <!-- END SIDEBAR USERPIC -->
            <!-- SIDEBAR USER TITLE -->
            <div class="profile-usertitle">
               <div class="profile-usertitle-name">
                  Name: {{$user['name']}}
               </div>
               <div class="profile-usertitle-name">
                  Email: {{$user['email']}}
               </div>
            </div>
            <!-- END SIDEBAR USER TITLE -->
            <!-- SIDEBAR BUTTONS -->
            <div class="profile-userbuttons">

            </div>
            <!-- END SIDEBAR BUTTONS -->

         </div>
      </div>

      <!-- cart items details -->

      <div class="small-container cart-page" id="ordersList">
         <table>
            <tr>
               <th>Product</th>
               <th>Quantity</th>
               <th>Subtotal</th>
               <th>Order Date</th>
            </tr>

            <tr>
               <td>
                  <div class="cart-info">
                     <img src="https://i.ibb.co/B3vYjvw/buy-1.jpg" alt="" />
                     <div>
                        <p>Red Printed T-Shirt</p>
                        <small>Price ₹500.00</small>
                        <br />
                        <a href="#">Remove</a>
                     </div>
                  </div>
               </td>
               <td><input type="number" value="1" /></td>
               <td>₹500.00</td>
            </tr>

         </table>

         <div class="total-price">
            <table>
               <tr>
                  <td>Subtotal</td>
                  <td>₹3500.00</td>
               </tr>

            </table>
         </div>
      </div>
      <!-- </div> -->

   </div>
</div>
</div>

@endsection

@push('head')
<script>
   var MenuItems = document.getElementById('MenuItems');
   MenuItems.style.maxHeight = '0px';

   function menutoggle() {
      if (MenuItems.style.maxHeight == '0px') {
         MenuItems.style.maxHeight = '200px';
      } else {
         MenuItems.style.maxHeight = '0px';
      }
   }

   function orders() {
      var x = document.getElementById("ordersList")
      x.style.display = "block";
   }
</script>
@endpush