<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductLineItems extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('product_line_items')) {
            Schema::create('product_line_items', function (Blueprint $table) {
                $table->id();
                $table->bigInteger('user_id')->unsigned()->nullable();
                $table->foreign('user_id')->references('id')->on('users');              
                $table->bigInteger('product_id')->unsigned()->nullable();
                $table->foreign('product_id')->references('id')->on('products');
                $table->decimal('price', 15, 2)->default('0')->nullable();
                $table->integer('quantity')->default('0')->nullable();
                $table->string('image')->nullable();
                $table->decimal('delivery_charge', 15, 2)->default('0')->nullable();
                $table->integer('session_id')->nullable();
                $table->string('ip_address', 45)->nullable();
                $table->string('name')->nullable();
                $table->softDeletes();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_line_items');
    }
}
