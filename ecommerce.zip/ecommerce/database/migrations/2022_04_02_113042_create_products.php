<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (!Schema::hasTable('products')) {
            Schema::create('products', function (Blueprint $table) {
                $table->id();
                $table->string('product_name')->nullable();
                $table->bigInteger('category_id')->unsigned()->nullable();
                $table->foreign('category_id')->references('id')->on('product_categories');
                $table->integer('total_delivery_time')->nullable(); //no. of days
                $table->decimal('product_cost', 15, 2)->default('0')->nullable();
                $table->decimal('tax', 15, 2)->default('0')->nullable();
                $table->decimal('delivery_charge', 15, 2)->default('0')->nullable();
                $table->decimal('total_price', 15, 2)->default('0')->nullable(); //price including tax
                $table->string('description')->nullable();
                $table->string('image')->nullable();
                $table->softDeletes();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
